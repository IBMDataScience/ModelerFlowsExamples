#!/bin/bash
set -e -o pipefail
MODELER_HOME=/opt/IBM/SPSS/ModelerServer/Cloud/
LD_LIBRARY_PATH=$MODELER_HOME/python/lib $MODELER_HOME/python_venv/bin/pip install \
  numpy \
  scipy \
  matplotlib
