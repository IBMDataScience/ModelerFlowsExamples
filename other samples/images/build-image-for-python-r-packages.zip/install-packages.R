install.packages(c(
"abind",
"AER",
"antiword",
"aplpack"),
repos='http://cran.rstudio.com')
